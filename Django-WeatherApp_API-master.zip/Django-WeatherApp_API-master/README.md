# Django-WeatherApp
This is an Air Quality Weather app that returns a score for the Quality of Air in a selected Zip Code. <br> Based on the returned value, the Color also changes
